<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','HomeController@index');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/usuarios', 'UsuarioController@index');

Route::get('/produtos', 'ProdutoController@index');

Route::get('/produtos/novo', 'ProdutoController@novo');

Route::get('/produtos/{cliente}/editar', 'ProdutoController@editar');

Route::post('/produtos/salvar', 'ProdutoController@salvar');

Route::patch('/produtos/{produto}', 'ProdutoController@atualizar');


Route::delete('/produtos/{produto}', 'ProdutoController@deletar');