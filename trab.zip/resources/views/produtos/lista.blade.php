@extends('layouts.app')

@section('content')
@if(!Auth::guest())
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                	<a class="pull-right btn btn-default" href="{{ url('produtos/novo') }}"> Novo produto</a>
                    <br>
                    <br>
                </div>
                <div class="panel-body">

                 @if(Session::has('mensagem_sucesso'))
                    <div class="alert alert-success">{{Session::get('mensagem_sucesso')}}</div>
                    @endif
            		
            	@foreach($produtos as $produto)
                <article class="panel-body" id="container_produto">
						<figure><img src="{{URL::asset('img/'. $produto->imagem)}}" alt="Imagem do produto"></figure>



					 	<div id="infoproduto">
            				{{$produto->name}} <br>
            				{{$produto->description}} 
            				{{$produto->quantity}} <br>
            				<div id="valor">R$:{{$produto->price}}</div>
        				</div>

                        <a href="produtos/{{ $produto->id}}/editar" class="btn btn-default">Editar</a>
                        {!! Form::open(['method' => 'DELETE', 'url' => '/produtos/'.$produto->id, 'style' => 'display: inline;']) !!}
                         <button type="submit" class="pull-right btn btn-default" >Excluir</button>
                         {!! Form::close() !!}
				</article>
				@endforeach
                	
                </div>  

                </div>   
            </div>
        </div>
    </div>
</div>
@endif
@endsection
